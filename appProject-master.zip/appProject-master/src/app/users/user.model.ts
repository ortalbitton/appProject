export interface User {
  id: string;
  name: string;
  password: string;
  latitude: number;
  longitude: number;
}
