export class MapPoint {
    latitude: number;
    longitude: number;
}