export interface Admin {
  id: string;
  name: string;
}
